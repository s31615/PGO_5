public class Technologia {
    String nazwa;
    int premia;

    public Technologia(String nazwa, int premia) {
        this.nazwa = nazwa;
        this.premia = premia;
    }
}
