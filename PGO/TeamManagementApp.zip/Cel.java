public class Cel {
    int rok;
    int miesiąc;
    int dzień;
    String nazwa;
    int premia;

    public Cel(int rok, int miesiąc, int dzień, String nazwa, int premia) {
        this.rok = rok;
        this.miesiąc = miesiąc;
        this.dzień = dzień;
        this.nazwa = nazwa;
        this.premia = premia;
    }
}
